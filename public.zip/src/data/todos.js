export const todos = [
  {
    title: "this is some title",
    description:"this is some description",
    status: 'completed',
    author: 'shahid'
},
{
    title: "this is another title",
    description:"this is another description",
    status: 'pending',
    author: 'yasir'
},
{
  title: "this is Third title",
  description:"this is another description",
  status: 'pending',
  author:" bilal"
},

]
