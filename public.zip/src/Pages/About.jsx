


const About = () => {
    return (
        <div className="container">
            <h1>About Us</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad officia aliquam id in ratione accusantium voluptates repellendus odit. Eaque nobis temporibus consectetur inventore, ea est repellendus tenetur. Eligendi, eveniet iusto. Temporibus doloremque, ab modi officiis aliquid obcaecati, possimus voluptate pariatur libero quibusdam dignissimos magni alias aut tempora eveniet dolore nam?</p>
        </div>
    );
}
 
export default About;